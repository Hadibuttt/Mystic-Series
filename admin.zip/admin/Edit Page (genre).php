<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Page(genre)</title>
</head>
<body>

<?php
$id=$_GET['edit'];
echo "<table style='border:1px solid black;'>
<thead>
<tr>
    <th style='border:1px solid black;'>genre_id</th>
    <th style='border:1px solid black;'>genre</th>
    <th style='border:1px solid black;'>Edit</th>
    <th style='border:1px solid black;'>Delete</th>
    </tr>
    </thead>
    <tbody>";
   
    include("../Php and Database Connection.php");
    $sql="SELECT * FROM genre WHERE genre_id='$id'";
    $result=$conn->query($sql);
        if($result->num_rows>0)
             {
                 while($row=$result->fetch_assoc())
                        {
                            $A=$row['genre_id'];
                            $B=$row['genre'];

                            echo "
                            <tr>
                            <td style='border:1px solid black;'>$A</td>
                            <td style='border:1px solid black;'>$B</td>
                            <td style='border:1px solid black;'><a href='Edit Page of Mystic Series(genre).php?edit=$A'>Edit</a></td>
                            <td style='border:1px solid black;'><a href=''>Delete</a></td>
                            </tr>";   
                            }

                        }
                        
                                      else
                             {
                                 echo "ERROR";
                             }
                      
                             echo "</tbody>
                             </table>";


?>

<?php

include("../Php and Database Connection.php");
$sql="SELECT genre FROM genre WHERE genre_id='$id'";
$result=$conn->query($sql);
    if($result->num_rows>0)
         {
             while($row=$result->fetch_assoc())
                    {   
                        $B=$row['genre'];
                       
                    
                
        ?>

<form action="" method="POST">
<br>

<input type="text" name="1" value="<?php echo $B; ?>">
<button type="submit" name="btn">Edit</button>
</form>

<?php
    }
}
?>



<?php
include("../Php and Database Connection.php");

if(isset($_POST['btn']))

{
    $genre= $_POST['1'];

    $sql="UPDATE genre SET genre='$genre' WHERE genre_id='$id'";
    if($conn->query($sql)===TRUE)
        {
            echo "DATA EDITED SUCCESSFULLY";
        }

        else
        {
            echo "Error";
        }

}
?>

</body>
</html>