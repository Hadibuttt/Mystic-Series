<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Page Mystic Series</title>
</head>
<body>
    
<?php
$id=$_GET['edit'];
echo "<table style='border:1px solid black;'>
<thead>
<tr>
    <th style='border:1px solid black;'>Episode id</th>
    <th style='border:1px solid black;'>Series name</th>
    <th style='border:1px solid black;'>Genre id</th>
    <th style='border:1px solid black;'>Image</th>
    <th style='border:1px solid black;'>Description</th>
    <th style='border:1px solid black;'>IMDB link</th>
    <th style='border:1px solid black;'>Rating</th>
    <th style='border:1px solid black;'>Series views</th>
    <th style='border:1px solid black;'>Season views</th>
    <th style='border:1px solid black;'>Episode views</th>
    <th style='border:1px solid black;'>Season id</th>
    <th style='border:1px solid black;'>Recently added date</th>
    <th style='border:1px solid black;'>Total Episodes</th>    
    <th style='border:1px solid black;'>Cast</th>        
    <th style='border:1px solid black;'>Run time</th>   
    <th style='border:1px solid black;'>Genre</th>        
    <th style='border:1px solid black;'>Edit</th>
    <th style='border:1px solid black;'>Delete</th>
    </tr>
</thead>
<tbody>";

include("../Php and Database Connection.php");
$sql="SELECT * FROM series WHERE episode_id='$id'";
$result=$conn->query($sql);
    if($result->num_rows>0)
         {
             while($row=$result->fetch_assoc())
                    {
                        $A=$row['episode_id'];
                        $B=$row['series_name'];
                        $C=$row['genre_id'];
                        $D=$row['image'];
                        $E=$row['description'];
                        $F=$row['imdb_link'];
                        $G=$row['rating'];
                        $H=$row['series_views'];
                        $I=$row['season_views'];
                        $J=$row['episode_views'];
                        $K=$row['season_id'];
                        $L=$row['recently_added_date'];
                        $M=$row['episodes_id'];
                        $N=$row['Cast'];
                        $O=$row['run_time'];
                        $P=$row['genre'];
                       
                        echo "
                        <tr>
                        <td style='border:1px solid black;'>$A</td>
                        <td style='border:1px solid black;'>$B</td>
                        <td style='border:1px solid black;'>$C</td>
                        <td style='border:1px solid black;'>$D</td>
                        <td style='border:1px solid black;'>$E</td>
                        <td style='border:1px solid black;'>$F</td>
                        <td style='border:1px solid black;'>$G</td>
                        <td style='border:1px solid black;'>$H</td>
                        <td style='border:1px solid black;'>$I</td>
                        <td style='border:1px solid black;'>$J</td>
                        <td style='border:1px solid black;'>$K</td>
                        <td style='border:1px solid black;'>$L</td>
                        <td style='border:1px solid black;'>$M</td>                        
                        <td style='border:1px solid black;'>$N</td>                                                
                        <td style='border:1px solid black;'>$O</td>                                                
                        <td style='border:1px solid black;'>$P</td> 
                        <td style='border:1px solid black;'><a href='Edit Page of Mystic Series .php?edit=$A'>Edit</a></td>
                        <td style='border:1px solid black;'><a href=''>Delete</a></td>
                        </tr>";   
                        }
      
                }
      
                    else
           {
               echo "ERROR";
           }
    
           echo "</tbody>
           </table>";
?>
<?php
    include("../Php and Database Connection.php");
    $sql="SELECT * FROM series WHERE episode_id='$id'";
    $result=$conn->query($sql);
        if($result->num_rows>0)
             {
                 while($row=$result->fetch_assoc())
                        {
                            $B=$row['series_name'];
                            $C=$row['genre_id'];
                            $E=$row['description'];
                            $F=$row['imdb_link'];
                            $G=$row['rating'];
                            $H=$row['series_views'];
                            $I=$row['season_views'];
                            $J=$row['episode_views'];
                            $K=$row['season_id'];
                            $L=$row['recently_added_date'];
                            $M=$row['episodes_id'];
                            $D=$row['image'];
                            $N=$row['Cast'];
                            $O=$row['run_time'];
                            $P=$row['genre'];
                            ?>
<form action="" method="POST" enctype="multipart/form-data">
<br>
<input type="text" name="2" value="<?php echo $B; ?>">
<br>

<input type="text" name="3" value="<?php echo $C; ?>">
<br>

<textarea name="4" cols="30" rows="10"><?php echo $E;?></textarea> 
<br>

<input type="text" name="5" value="<?php echo $F; ?>">
<br>

<input type="text" name="6" value="<?php echo $G; ?>">
<br>

<input type="text" name="7" value="<?php echo $H; ?>">
<br>

<input type="text" name="8" value="<?php echo $I; ?>">
<br>

<input type="text" name="9" value="<?php echo $J; ?>">
<br>

<input type="text" name="10" value="<?php echo $K; ?>">
<br>

<input type="text" name="11" value="<?php echo $L; ?>">
<br>

<input type="text" name="12" value="<?php echo $M; ?>">
<br>

<input type="text" name="13" value="<?php echo $N; ?>">
<br>

<input type="text" name="14" value="<?php echo $O; ?>">
<br>

<input type="text" name="15" value="<?php echo $P; ?>">
<br>

<br>
<input type="file" name="image">
<br>

<br>
<button type="submit" name="btn">Edit</button>
</form>
<?php
    }
}
?>

<?php
include("../Php and Database Connection.php");

if(isset($_POST['btn']))

{
    $series_name= $_POST['2'];
    $genre_id= $_POST['3'];
    $pimage=$_FILES['image']['name'];
    $path="../Series Images/".$pimage;
    $description= $_POST['4'];
    $imdb_link= $_POST['5'];
    $rating= $_POST['6'];
    $series_views= $_POST['7'];
    $season_views= $_POST['8'];
    $episode_views= $_POST['9'];
    $season_id= $_POST['10'];
    $recently_added_date= $_POST['11'];
    $episodes_id= $_POST['12'];
    $Cast=$_POST['13'];
    $run_time=$_POST['14'];
    $genre=$_POST['15'];

    $sql="UPDATE series SET series_name='$series_name',genre_id='$genre_id',image='$pimage',description='$description',imdb_link='$imdb_link',rating='$rating',series_views='$series_views',season_views='$season_views',episode_views='$episode_views',season_id='$season_id',recently_added_date='$recently_added_date',episodes_id='$episodes_id',Cast='$Cast',run_time='$run_time',genre='$genre' WHERE episode_id='$id'";
    if($conn->query($sql)===TRUE)
    if(move_uploaded_file($_FILES['image']['tmp_name'],($path)))
        {
            echo "DATA EDITED SUCCESSFULLY";
        }

        else
        {
            echo "DATA EDITED SUCCESSFULLY";
        }

}


?>




</body>
</html>