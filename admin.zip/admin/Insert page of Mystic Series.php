<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Insert Page Mystic Series</title>
</head>
<body>
    
<form action="" method="POST" enctype="multipart/form-data">

<input type="text" name="2" placeholder="Enter series name">
<br>

<input type="text" name="3" placeholder="Enter genre id">
<br>

<textarea name="4" cols="30" rows="10" placeholder="Enter description"></textarea> 
<br>

<input type="text" name="5" placeholder="Enter imdb link">
<br>

<input type="text" name="6" placeholder="Enter rating">
<br>

<input type="text" name="7" placeholder="Enter series views">
<br>

<input type="text" name="8" placeholder="Enter season views">
<br>

<input type="text" name="9" placeholder="Enter episode views">
<br>

<input type="text" name="10" placeholder="Enter season id">
<br>

<input type="text" name="11" placeholder="Enter recently added date">
<br>

<input type="text" name="12" placeholder="Enter Total Episodes">
<br>

<input type="text" name="13" placeholder="Enter cast">
<br>

<input type="text" name="14" placeholder="Enter Run time">
<br>

<input type="text" name="15" placeholder="Enter Genre">
<br>

<br>
<input type="file" name="image">
<br>

<br>
<button type="submit" name="btn">Insert</button>
</form>

<?php

include("../Php and Database Connection.php");

if(isset($_POST['btn']))

{
    $series_name= $_POST['2'];
    $genre_id= $_POST['3'];
    $pimage=$_FILES['image']['name'];
    $path="../Series Images/".$pimage;
    $description= $_POST['4'];
    $imdb_link= $_POST['5'];
    $rating= $_POST['6'];
    $series_views= $_POST['7'];
    $season_views= $_POST['8'];
    $episode_views= $_POST['9'];
    $season_id= $_POST['10'];
    $recently_added_date= $_POST['11'];
    $episodes_id=$_POST['12'];
    $Cast=$_POST['13'];
    $run_time=$_POST['14'];
    $genre=$_POST['15'];

    $sql="INSERT INTO series(series_name,genre_id,image,description,imdb_link,rating,series_views,season_views,episode_views,season_id,recently_added_date,episodes_id,Cast,run_time,genre) VALUES('$series_name','$genre_id','$pimage','$description','$imdb_link','$rating','$series_views','$season_views','$episode_views','$season_id','$recently_added_date','$episodes_id','$Cast','$run_time','$genre')";
    $conn->query($sql);
    if(move_uploaded_file($_FILES['image']['tmp_name'],($path)))
    
            {
                echo "Data Inserted succesfully";
            }
            
            
            else
            
            {
                echo "Error";
            }        

}
?>


</body>
</html>