<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Insert Page(Genre)</title>
</head>
<body>

<form action="" method="post">
<input type="text" name="1" placeholder="Enter genre name">

<button type="submit" name="btn">Insert</button>
</form>  

<?php
include("../Php and Database Connection.php");

if(isset($_POST['btn']))

{
    $A= $_POST['1'];

    $sql="INSERT INTO genre(genre) VALUES('$A')";
    if($conn->query($sql)===TRUE)
    
            {
                echo " DATA INSERTED SUCCESSFULLY";
            }
    
            else
            {
                echo "error";
            }
    
}

?>


</body>
</html>