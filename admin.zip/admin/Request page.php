<head>
<title>Request Page</title>
</head>
<?php


echo "<table style='border:1px solid black;'>
<thead>
<tr>
    <th style='border:1px solid black;'>User ID</th>
    <th style='border:1px solid black;'>Request</th>
    </tr>
    </thead>
    <tbody>";

include("../Php and Database Connection.php");
$sql="SELECT * FROM feedback";
$result=$conn->query($sql);
    if($result->num_rows>0)
         {
             while($row=$result->fetch_assoc())
                    {
                        $A=$row['id'];
                        $B=$row['feedback'];
                        echo "
                        <tr>
                        <td style='border:1px solid black;'>$A</td>
                        <td style='border:1px solid black;'>$B</td>
                        </tr>";   
                    }
  
            }
  
                else
       {
           echo "ERROR";
       }

       echo "</tbody>
       </table>";
?>

