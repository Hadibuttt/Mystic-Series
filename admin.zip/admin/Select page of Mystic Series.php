<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Select Page Mystic Series</title>
</head>
<body>
    
<!--Select Query of whole database-->
<?php


echo "<table style='border:1px solid black;'>
<thead>
<tr>
    <th style='border:1px solid black;'>Episode id</th>
    <th style='border:1px solid black;'>Series name</th>
    <th style='border:1px solid black;'>Genre id</th>
    <th style='border:1px solid black;'>Image</th>
    <th style='border:1px solid black;'>Description</th>
    <th style='border:1px solid black;'>IMDB link</th>
    <th style='border:1px solid black;'>Rating</th>
    <th style='border:1px solid black;'>Series views</th>
    <th style='border:1px solid black;'>Season views</th>
    <th style='border:1px solid black;'>Episode views</th>
    <th style='border:1px solid black;'>Season id</th>
    <th style='border:1px solid black;'>Recently added date</th>
    <th style='border:1px solid black;'>Total Episodes</th>    
    <th style='border:1px solid black;'>Cast</th>        
    <th style='border:1px solid black;'>Genre</th>        
    <th style='border:1px solid black;'>Run time</th>            
    <th style='border:1px solid black;'>Edit</th>
    <th style='border:1px solid black;'>Delete</th>
    </tr>
</thead>
<tbody>";

include("../Php and Database Connection.php");
$sql="SELECT episode_id,series_name,genre_id,image,description,imdb_link,rating,series_views,season_views,episode_views,season_id,recently_added_date,episodes_id,Cast,run_time,genre FROM series";
$result=$conn->query($sql);
    if($result->num_rows>0)
         {
             while($row=$result->fetch_assoc())
                    {
                        $A=$row['episode_id'];
                        $B=$row['series_name'];
                        $C=$row['genre_id'];
                        $D=$row['image'];
                        $E=$row['description'];
                        $F=$row['imdb_link'];
                        $G=$row['rating'];
                        $H=$row['series_views'];
                        $I=$row['season_views'];
                        $J=$row['episode_views'];
                        $K=$row['season_id'];
                        $L=$row['recently_added_date'];
                        $M=$row['episodes_id'];
                        $N=$row['Cast'];
                        $O=$row['run_time'];
                        $P=$row['genre'];

                        echo "
                        <tr>
                        <td style='border:1px solid black;'>$A</td>
                        <td style='border:1px solid black;'>$B</td>
                        <td style='border:1px solid black;'>$C</td>
                        <td style='border:1px solid black;'>$D</td>
                        <td style='border:1px solid black;'>$E</td>
                        <td style='border:1px solid black;'>$F</td>
                        <td style='border:1px solid black;'>$G</td>
                        <td style='border:1px solid black;'>$H</td>
                        <td style='border:1px solid black;'>$I</td>
                        <td style='border:1px solid black;'>$J</td>
                        <td style='border:1px solid black;'>$K</td>
                        <td style='border:1px solid black;'>$L</td>
                        <td style='border:1px solid black;'>$M</td>                        
                        <td style='border:1px solid black;'>$N</td>                                                
                        <td style='border:1px solid black;'>$O</td>                                                
                        <td style='border:1px solid black;'>$P</td>                                                                        
                        <td style='border:1px solid black;'><a href='Edit Page of Mystic Series .php?edit=$A'>Edit</a></td>
                        <td style='border:1px solid black;'><a href='Select page of Mystic Series.php?delete=$A'>Delete</a></td>
                        </tr>";   
                        }
      
                }
      
                    else
           {
               echo "ERROR";
           }
    
           echo "</tbody>
           </table>";
?>

<?php
if(isset($_GET['delete']))
{
$id=$_GET['delete'];
$sql="DELETE FROM series WHERE episode_id='$id'";
if($conn->query($sql)===TRUE)
{
    echo "Data Deleted Successfully";
}
else
{
    echo "Error In Deleting Data";
}

}

?>


</body>
</html>