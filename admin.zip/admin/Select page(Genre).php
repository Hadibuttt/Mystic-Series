<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Select page(genre)</title>
</head>
<body>
    


<!--Select Query of whole database-->
    <?php
echo "<table style='border:1px solid black;'>
<thead>
<tr>
    <th style='border:1px solid black;'>genre_id</th>
    <th style='border:1px solid black;'>genre</th>
    <th style='border:1px solid black;'>Edit</th>
    <th style='border:1px solid black;'>Delete</th>
    </tr>
    </thead>
    <tbody>";
   
    include("../Php and Database Connection.php");
    $sql="SELECT genre_id,genre FROM genre";
    $result=$conn->query($sql);
        if($result->num_rows>0)
             {
                 while($row=$result->fetch_assoc())
                        {
                            $A=$row['genre_id'];
                            $B=$row['genre'];

                            echo "
                            <tr>
                            <td style='border:1px solid black;'>$A</td>
                            <td style='border:1px solid black;'>$B</td>
                            <td style='border:1px solid black;'><a href='Edit Page of Mystic Series(genre).php?edit=$A'>Edit</a></td>
                            <td style='border:1px solid black;'><a href='Select page of Mystic Series(Genre).php?delete=$A'>Delete</a></td>
                            </tr>";   
                            }

                        }
                        
                                      else
                             {
                                 echo "ERROR";
                             }
                      
                             echo "</tbody>
                             </table>";

?>



<?php
if(isset($_GET['delete']))
{
$id=$_GET['delete'];
$sql="DELETE FROM genre WHERE genre_id='$id'";
if($conn->query($sql)===TRUE)
{
    echo "Data Deleted Successfully";
}
else
{
    echo "Error In Deleting Data";
}

}

?>

</body>
</html>