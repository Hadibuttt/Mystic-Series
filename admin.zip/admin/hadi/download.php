<?php include("config.php");?>
<h1>Download</h1>
<?php
    $season_id=$_GET['season_id'];
    $series_id=$_GET['series_id'];
    $episode_id=$_GET['episode_id'];
    $sql="select * from download_link WHERE season_id='$season_id' AND series_id='$series_id' AND episode_id='$episode_id'";
    $result=$conn->query($sql);
    while($row=$result->fetch_assoc())
    {
        $id=$row['id'];
        $season_title=$row['link'];
        echo"
        <h1><a href=''>$season_title</a></h1>";
    }    
?>