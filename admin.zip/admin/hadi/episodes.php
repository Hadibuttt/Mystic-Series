<?php include("config.php");?>
<h1>Episodes</h1>
<?php
    $season_id=$_GET['season_id'];
    $series_id=$_GET['series_id'];
    $sql="select * from episodes WHERE season_id='$season_id' AND series_id='$series_id'";
    $result=$conn->query($sql);
    while($row=$result->fetch_assoc())
    {
        $id=$row['id'];
        $season_title=$row['episode_title'];
        echo"
        <h1><a href='download.php?season_id=$season_id&series_id=$series_id&episode_id=$id'>$season_title</a></h1>";
    }    
?>