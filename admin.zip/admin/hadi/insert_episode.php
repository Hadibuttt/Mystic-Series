<?php
include("Php and Database Connection.php");
?>
<h1>Insert Episode</h1>

<form action="" method="POST" role="form">
    <label for="exampleInputEmail1">Series</label>
    <select name="series" required="required">
        <option value="">Select Series</option>
        <?php
            $sql="SELECT * FROM series";
                $result=$conn->query($sql);
                while($row=$result->fetch_assoc())
                    {
                        $episode_id=$row['episode_id'];
                        $series_name=$row['series_name'];
                        echo "<option value='$episode_id'>$series_name</option>";
                    }
        ?>
    </select>
    <label for="exampleInputEmail1">Season</label>
    <select name="season" required="required">
        <option value="">Select Season</option>
        <?php
            $sql="SELECT * FROM seasons LIMIT 10";
                $result=$conn->query($sql);
                while($row=$result->fetch_assoc())
                    {
                        $id=$row['id'];
                        $season_title=$row['season_title'];
                        echo "<option value='$id'>$season_title</option>";
                    }
        ?>
    </select>
    <label for="exampleInputEmail1">Episode</label>
    <select name="episode" required="required">
        <option value="">Select Episode</option>
        <?php
            $sql="SELECT * FROM episodes LIMIT 30";
                $result=$conn->query($sql);
                while($row=$result->fetch_assoc())
                    {
                        $id=$row['id'];
                        $episode_title=$row['episode_title'];
                        echo "<option value='$id'>$episode_title</option>";
                    }
        ?>
    </select>
    

    <button type="submit" name="btn" class="btn btn-primary">Submit</button>
</form>
<?php
    if(isset($_POST['btn']))
    {
        $season_id=$_POST['season'];
        $series_id=$_POST['series'];
        $episode_id=$_POST['episode'];
        $sql="SELECT * FROM episodes WHERE id='$episode_id'";
        $result=$conn->query($sql);
        $row=$result->fetch_assoc();
    
            $episode_title=$row['episode_title'];
        $sql1="INSERT INTO episodes(id,episode_title,series_id,season_id)
        VALUES('$episode_id','$episode_title','$series_id','$season_id')";
        mysqli_query($conn,$sql1);
        
    }
?>