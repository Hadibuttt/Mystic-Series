<?php
include("Php and Database Connection.php");
?>

<h1>Seasons</h1>
<?php
    $series_id=$_GET['series_id'];
    $sql="select * from seasons WHERE series_id='$series_id'";
    $result=$conn->query($sql);
    while($row=$result->fetch_assoc())
    {
        $id=$row['id'];
        $season_title=$row['season_title'];
        echo"
        <h1><a href='episodes.php?season_id=$id&series_id=$series_id'>$season_title</a></h1>";
    }    
?>